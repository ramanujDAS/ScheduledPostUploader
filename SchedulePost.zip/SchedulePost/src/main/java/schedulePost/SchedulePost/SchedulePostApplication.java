package schedulePost.SchedulePost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedulePostApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedulePostApplication.class, args);
	}

}
